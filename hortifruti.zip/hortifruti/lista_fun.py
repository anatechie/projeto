import sqlite3 
from rich.console import  Console
import os 

console = Console()

def conexao():
    
    try:
        conn = sqlite3.connect('hortifruti.db')
        console.print(f"[green]Conexão bem sucedida![/green]")
        return conn
    except sqlite3.DatabaseError as erro:
        console.print(f"[bold dark red]Erro ao conectar ao banco de dados: {erro}[/bold dark red]")
        return None

def listar_funcionarios(conn):
    cursor = conn.cursor()
    cursor.execute("""SELECT * FROM funcionario""")
    funcionarios = cursor.fetchall()
    if funcionarios:
        console.print(f'[blue]Lista de Funcionários:[/blue]')
        for funcionario in funcionarios:
            console.print(f'ID: {funcionario[0]}, Nome: {funcionario[1]}')
    else:
        console.print('[yellow]Nenhum funcionário cadastrado.[/yellow]')

conn = conexao()
try:
        if conn:
            cursor = conn.cursor()
            listar_funcionarios(conn)
            conn.close()
        else:
            console.print(f'[bold dark red]Não foi possível  realizar operações no banco de dados.[/bold dark red]')
except  Exception as erro: 
    console.print(f'[red]Não foi possível conectar ao banco de dados.[/red]')
finally:
    console.print(f'[green]Conexão encerrada com sucesso.[/green]')