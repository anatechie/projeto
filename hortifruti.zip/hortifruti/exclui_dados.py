import sqlite3
from rich.console import Console
from rich.table import Table
import os

console = Console(

)
def conexao():
    try:
        conn = sqlite3.connect('hortifruti.db')
        console.print(f"[green]Conexão bem sucedida![/green]")
        return conn
    except sqlite3.DatabaseError as erro:
        console.print(f"[bold dark red]Erro ao conectar ao banco de dados: {erro}[/bold dark red]")
        return None
    
def excluir_funcionario(conn):
    try: 
        cursor = conn.cursor()
        exclui = """DELETE FROM funcionarios WHERE id = ?"""
        cursor.execute(exclui, (id,)) 
        conn.commit() 
        console.print(f'[red]Funcionário com ID {id} excluído.[/red]')
    except sqlite3.DatabaseError as erro: 
        console.print(f"[bold dark red]Erro ao excluir funcionário: {erro}[/bold dark red]")
        try: 
            if conn:
                id = int(input("Digite o ID do funcionário a ser excluído: "))
                excluir_funcionario(id, conn) 
            else: console.print(f'[bold dark red]Não foi possível realizar operações no banco de dados.[/bold dark red]') 
        except Exception as erro: console.print(f'[red]Erro ao executar operação no banco de dados: {erro}[/red]') 
        finally:
             if conn: 
                conn.close() 
                console.print(f'[green]Conexão encerrada com sucesso.[/green]')