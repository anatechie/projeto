import sqlite3 
from rich.console import Console

console = Console()

def conexao():
    try:
        conn = sqlite3.connect('hortifruti.db')
        console.print(f"[green]Conexão bem sucedida![/green]")
        return conn
    except sqlite3.DatabaseError as erro:
        console.print(f"[bold dark red]Erro ao conectar ao banco de dados: {erro}[/bold dark red]")
        return conn
    
def incluir_fruta(cursor, conn):
    cursor = conn.cursor()
    Nome_produto = input('Informe o produto: \t')
    Preco = input('Informe o preço do produto: \t')
    Tipo_Produto = input('Informe o tipo do produto: \t')
    Peso = input('Informe o peso: \t')
    Quantidade = input('Informe a quantidade: \t')
    Descricao = input('Informe o endereço do cliente: \t')
    cursor.execute(
       """
            INSERT INTO fruta (Nome_produto, Preco, Tipo_Produto,Peso,
        Quantidade, Descricao) VALUES (?, ?, ?, ?, ?, ?)
            """, (Nome_produto, Preco, Tipo_Produto,Peso,
        Quantidade, Descricao)
        )
    conn.commit()
    console.print(f'[green]Funcionário "{nome}" inserido com sucesso![/green]')