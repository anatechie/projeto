import sqlite3 
from rich.console import Console

console = Console()

def conexao():
    conn 
    try:
        conn = sqlite3.connect('hortifruti.db')
        console.print(f"[green]Conexão bem sucedida![/green]")
        return conn
    except sqlite3.DatabaseError as erro:
        console.print(f"[bold dark red]Erro ao conectar ao banco de dados: {erro}[/bold dark red]")
        return conn

def listar_fruta():
    cursor = conn.cursor()
    frutas = []

    console.print('[purple]Informe a quantidade de frutas a serem inseridas:\t[/purple]')
    x = int(input())
    
    for i in range(x):
        console.print(f'[purple]Informe o nome da fruta {i+1}:[/purple]')
        fruta = input()
        frutas.append(fruta)
        console.print(f'[purple]Frutas até agora: {frutas}[/purple]')
        console.print(f'[yellow]--------------------------------------------------------------------[/yellow]')
    return frutas

conn = conexao()
frutas_listadas = listar_fruta()
console.print(f'[magenta]frutas listadas: {frutas_listadas}[/magenta]')

        
cursor.execute("SELECT * FROM frutas")
fruta = cursor.fetchall()

if fruta:
    console.print(f'[green]Frutas existentes no banco de dados: {fruta}[/green]')
    for fruit in fruta:
        console.print(f'[green]Fruta: {fruit}[/green]')
    else: 
        console.print(f'[bold dark red]Não há frutas no banco de dados[/bold dark]')

    conn.close()

listar_fruta()


    