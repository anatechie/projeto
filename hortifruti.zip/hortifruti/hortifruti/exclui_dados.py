import sqlite3
from rich.console import Console
from rich.table import Table
from consulta_dados import consulta_dado
import os

console = Console(

)
def conexao():
    try:
        conn = sqlite3.connect('hortifruti.db')
        console.print(f"[green]Conexão bem sucedida![/green]")
        return conn
    except sqlite3.DatabaseError as erro:
        console.print(f"[bold dark red]Erro ao conectar ao banco de dados: {erro}[/bold dark red]")
        return conn
    
def consulta_dados():
    os.system('cls')
    
try:
    def exclui_cliente(nome):
        conn = conexao()
        cursor = conn.cursor()

        cursor.execute(
            """
            DELETE FROM cliente WHERE nome = "Ana";
            """, (nome)
        )
    conn.commit()
    console.print(f"[green]Cliente de nome {nome} excluído com sucesso![/green]")
except sqlite3.Error as erro: 
    console.print(f"[bold dark red]Erro ao excluir cliente: {erro}[/bold]")
finally:
    conn.close()