import sqlite3 
from rich.console import  Console
import os 

console = Console()

def conexao():
    
    try:
        conn = sqlite3.connect('hortifruti.db')
        console.print(f"[green]Conexão bem sucedida![/green]")
        return conn
    except sqlite3.DatabaseError as erro:
        console.print(f"[bold dark red]Erro ao conectar ao banco de dados: {erro}[/bold dark red]")
        return conn
    
def insere_fun(conn):
    cursor = conn.cursor()
    

def inserir_funcionariobd(conn):
    cursor = conn.cursor()
    cursor.execute('INSERT INTO funcionarios (nome) VALUES (?)', (nome,))
    conn.commit()
    console.print(f'[green]Funcionário "{nome}" inserido com sucesso![/green]')