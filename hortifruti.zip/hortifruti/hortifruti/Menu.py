import sqlite3
import os
from rich.console import Console
from lista_fruta import lista_fruta
from inclui_produto import incluir_fruta

console = Console()

def menu():
    while True:
        os.system('cls')

        console.print(f'[magenta]+------------------------+[/magenta]')
        console.print(f'[magenta]|________________________|[/magenta]')
        console.print(f'[magenta]|     MENU INICIAL:      |[/magenta]')
        console.print(f'[magenta]|________________________|[/magenta]')
        console.print(f'[magenta]|      (1)FUNCIONARIOS   |[/magenta]')
        console.print(f'[magenta]|      (2)INCLUIR        |[/magenta]')
        console.print(f'[magenta]|      (3)EDITAR         |[/magenta]')
        console.print(f'[magenta]|      (4)APAGAR         |[/magenta]')
        console.print(f'[magenta]|      (5)VOLTAR AO MENU |[/magenta]')
        console.print(f'[magenta]|________________________|[/magenta]')
        console.print(f'[magenta]|________________________|[/magenta]')
        console.print(f'[magenta]+------------------------+[/magenta]')

        op = input(f'[purple]Digite a opção:\t[/purple]')

        if op == '1':
            lista_fruta()
        elif op == '2':
            incluir_fruta()
        elif op == '3':
            editar_fruta()
        elif op == '4':
            apagar_fruta()
            
        else:
            console.print(f'[red]Opção inválida. Pressione enter para continuar"[/red]') 
            menu()
def lista_fruta():
    os.system('cls')
def incluir_fruta():
    os.system('cls')
def editar_fruta():
    os.system('cls')
def apagar_fruta():
    os.system('cls')

menu()
    












