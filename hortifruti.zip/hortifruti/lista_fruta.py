import sqlite3 
from rich.console import Console

console = Console()

def conexao():
    try:
        conn = sqlite3.connect('hortifruti.db')
        console.print(f"[green]Conexão bem sucedida![/green]")
        return conn
    except sqlite3.DatabaseError as erro:
        console.print(f"[bold dark red]Erro ao conectar ao banco de dados: {erro}[/bold dark red]")
        return conn

'''def listar_fruta()
    frutas = []

    console.print('[purple]Informe a quantidade de frutas a serem inseridas:\t[/purple]')
    x = int(input())
    
    for i in range(x):
        console.print(f'[purple]Informe o nome da fruta {i+1}:[/purple]')
        fruta = input()
        frutas.append(fruta)
        console.print(f'[purple]Frutas até agora: {frutas}[/purple]')
        console.print(f'[yellow]--------------------------------------------------------------------[/yellow]')
    return frutas

conn = conexao()
if conn:
    frutas_listadas = listar_fruta()
    console.print(f'[magenta]frutas listadas: {frutas_listadas}[/magenta]')

for fruta in frutas_listadas:
  
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM produto")
    fruta = cursor.fetchall()

    if fruta:
        console.print(f'[green]Frutas existentes no banco de dados: {fruta}[/green]')
        for fruit in fruta:
            console.print(f'[green]Fruta: {fruit}[/green]')
    else: 
            console.print(f'[bold dark red]Não há frutas no banco de dados[/bold dark]')

    conn.close()
else:
    console.print(f'[bold dark red]Não foi possível realizar operações no banco de dados.[/bold dark red]')
'''


def listar_frutas(cursor):
    cursor = conn.cursor()
    cursor.execute(
        "SELECT * FROM produto"
    )
    frutas = cursor.fetchall()

    if frutas:
        console.print(f'[green]Frutas existentes no banco de dados: {frutas}')
        for fruta in frutas:
            console.print(f'[green]Fruta/Produto: {fruta}')
    else: 
        console.print(f'[bold dark red]Não há frutas registradas no ')

conn = conexao()
try:
        if conn:
            cursor = conn.cursor()
            listar_frutas(cursor)
            conn.close()
        else:
            console.print(f'[bold dark red]Não foi possível  realizar operações no banco de dados.[/bold dark red]')
except  Exception as erro: 
    console.print(f'[red]Não foi possível conectar ao banco de dados.[/red]')
finally:
    console.print(f'[green]Conexão encerrada com sucesso.[/green]')